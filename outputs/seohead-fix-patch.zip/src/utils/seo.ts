import type { SEOData, Profile } from '../types';
import { APP_CONFIG } from '../types';

export function generateWebSiteSchema() {
  return {
    '@type': 'WebSite',
    name: APP_CONFIG.name,
    url: APP_CONFIG.url,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${APP_CONFIG.url}/#/search?q={search_term_string}`,
    },
  };
}

export function generateOrganizationSchema() {
  return {
    '@type': 'Organization',
    name: APP_CONFIG.name,
    url: APP_CONFIG.url,
    description: APP_CONFIG.description,
  };
}

export function generatePersonSchema(profile: Profile) {
  return {
    '@type': 'Person',
    name: profile.username,
    alternateName: profile.user_id,
    jobTitle: profile.tag,
    description: profile.slogan,
    url: `${APP_CONFIG.url}/#/${profile.user_id}`,
  };
}

export function generateBlogPostingSchema(log: { content: string; created_at: string }, profile: Profile) {
  return {
    '@type': 'BlogPosting',
    headline: log.content.slice(0, 60),
    articleBody: log.content,
    author: {
      '@type': 'Person',
      name: profile.username,
    },
    datePublished: log.created_at,
  };
}

export function generateProfilePageSchema(profile: Profile) {
  return {
    '@type': 'ProfilePage',
    mainEntity: generatePersonSchema(profile),
  };
}

export function getDefaultSEO(): SEOData {
  return {
    title: `${APP_CONFIG.name} - ${APP_CONFIG.slogan}`,
    description: APP_CONFIG.description,
    keywords: ['个人主页', '黄页', 'AI', '认知', '索引', 'Cognition World'],
    ogType: 'website',
    canonicalUrl: APP_CONFIG.url,
  };
}

/**
 * 获取用户页面的 SEO 数据 - 安全降级版本
 * 修复：当 profile 字段缺失时提供默认值
 */
export function getUserSEO(profile: Profile | null | undefined): SEOData {
  // 安全降级：如果 profile 不存在，返回默认 SEO
  if (!profile) {
    return getDefaultSEO();
  }

  // 安全访问字段，提供默认值
  const username = profile.username || '用户';
  const userId = profile.user_id || '';
  const tag = profile.tag || '';
  const slogan = profile.slogan || `${tag} | ${APP_CONFIG.name}`;

  return {
    title: `${username} - ${APP_CONFIG.name}`,
    description: slogan,
    keywords: [username, tag, userId, '个人主页'],
    ogType: 'profile',
    canonicalUrl: userId ? `${APP_CONFIG.url}/#/${userId}` : APP_CONFIG.url,
  };
}
