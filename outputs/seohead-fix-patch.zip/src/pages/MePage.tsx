import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Calendar, Eye, EyeOff, LogOut, User, Edit3, X, Save, Send, Clock, Image, Upload, CheckCircle, AlertCircle, Trash2, Check } from 'lucide-react';
import { getCurrentUser, logout, updateProfile } from '../utils/auth';
import { getUserLogs, createLog, getUserBackgroundImages, uploadBackgroundImage, setActiveBackgroundImage, deleteBackgroundImage } from '../utils/storage';
import { LogData, BackgroundImageData, Profile } from '../types';
import { SEOHead } from '../components/SEOHead';
import { generateProfilePageSchema, generatePersonSchema } from '../utils/seo';

export default function MePage() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profile, setProfile] = useState<any>(null);
  const [logs, setLogs] = useState<LogData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ tag: '', slogan: '', location: '' });
  const [newLogContent, setNewLogContent] = useState('');
  const [isPublishing, setIsPublishing] = useState(false);
  const [backgroundImages, setBackgroundImages] = useState<BackgroundImageData[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showBgSettings, setShowBgSettings] = useState(false);
  const [uploadError, setUploadError] = useState('');

  useEffect(() => {
    const loadData = async () => {
      const { profile: userProfile } = await getCurrentUser();
      if (!userProfile) {
        navigate('/login');
        return;
      }
      setProfile(userProfile);
      setEditForm({
        tag: userProfile.tag,
        slogan: userProfile.slogan || '',
        location: userProfile.location
      });

      const userLogs = await getUserLogs(userProfile.user_id);
      setLogs(userLogs);

      const bgImages = await getUserBackgroundImages(userProfile.id);
      setBackgroundImages(bgImages);

      setIsLoading(false);
    };

    loadData();
  }, [navigate]);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const handleSave = async () => {
    if (!profile) return;
    const { profile: updated } = await updateProfile(profile.id, editForm);
    if (updated) {
      setProfile(updated);
      setIsEditing(false);
    }
  };

  const handlePublishLog = async () => {
    if (!profile || !newLogContent.trim()) return;
    setIsPublishing(true);
    const newLog = await createLog(profile.user_id, newLogContent.trim());
    if (newLog) {
      setLogs([newLog, ...logs]);
      setNewLogContent('');
    }
    setIsPublishing(false);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    if (!file.type.startsWith('image/')) {
      setUploadError('请上传图片文件');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setUploadError('图片大小不能超过5MB');
      return;
    }

    setIsUploading(true);
    setUploadError('');

    const newImage = await uploadBackgroundImage(profile.id, file);
    if (newImage) {
      setBackgroundImages([newImage, ...backgroundImages]);
    } else {
      setUploadError('上传失败，请重试');
    }

    setIsUploading(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSetActive = async (imageId: string) => {
    if (!profile) return;
    const success = await setActiveBackgroundImage(profile.id, imageId);
    if (success) {
      const updatedImages = backgroundImages.map(img => ({
        ...img,
        isActive: img.id === imageId
      }));
      setBackgroundImages(updatedImages);
    }
  };

  const handleDelete = async (imageId: string) => {
    const success = await deleteBackgroundImage(imageId);
    if (success) {
      setBackgroundImages(backgroundImages.filter(img => img.id !== imageId));
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending':
        return <AlertCircle className="w-4 h-4 text-amber-500" />;
      case 'rejected':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return '已通过';
      case 'pending':
        return '审核中';
      case 'rejected':
        return '已拒绝';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-gray-200 border-t-[#1a1a1a] rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) return null;

  const pageTitle = `${profile.username} | 认知界`;
  const pageDescription = profile.slogan || `${profile.username} — ${profile.tag}`;
  const pageUrl = `https://cognition.world/#/${profile.user_id}`;

  const jsonLd = [
    generateProfilePageSchema(profile),
    generatePersonSchema(profile),
  ];

  return (
    <>
      <SEOHead
        data={{
          title: pageTitle,
          description: pageDescription,
          keywords: [profile?.username || '', profile?.tag || '', '数字身份', '认知界'],
          ogType: 'profile',
          canonicalUrl: pageUrl,
        }}
        jsonLd={jsonLd}
      />
      <div className="min-h-screen bg-white">
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-[60vh] bg-gradient-to-b from-[#fafafa] via-white to-transparent" />
          <div className="absolute top-20 left-1/4 w-96 h-96 bg-gradient-radial from-gray-100/30 to-transparent rounded-full blur-3xl" />
        </div>

        <nav className="fixed top-0 left-0 right-0 z-50 glass">
          <div className="max-w-3xl mx-auto px-6 h-14 flex items-center justify-between">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-sm text-[#6b7280] hover:text-[#1a1a1a] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>返回首页</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowBgSettings(!showBgSettings)}
                className="p-2 text-[#6b7280] hover:text-[#1a1a1a] hover:bg-[#f5f5f5] rounded-lg transition-colors"
              >
                <Image className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="p-2 text-[#6b7280] hover:text-[#1a1a1a] hover:bg-[#f5f5f5] rounded-lg transition-colors"
              >
                <Edit3 className="w-4 h-4" />
              </button>
              <button
                onClick={handleLogout}
                className="p-2 text-[#6b7280] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </nav>

        <main className="relative z-10 pt-32 pb-20 px-6">
          <div className="max-w-xl mx-auto">
            <motion.div
              className="text-center mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
            >
              <motion.div
                className="w-20 h-20 mx-auto mb-6 bg-[#1a1a1a] rounded-2xl flex items-center justify-center shadow-lg"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <span className="text-white font-semibold text-2xl">{profile.username?.[0] || 'U'}</span>
              </motion.div>

              <motion.h1
                className="text-2xl font-semibold text-[#1a1a1a] mb-2 tracking-tight"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                {profile.username}
              </motion.h1>

              <motion.p
                className="text-sm text-[#6b7280] mb-4"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.25 }}
              >
                {profile.tag}
              </motion.p>

              {profile.slogan && (
                <motion.p
                  className="text-[#6b7280] leading-relaxed max-w-md mx-auto text-[0.9375rem]"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  {profile.slogan}
                </motion.p>
              )}
            </motion.div>

            <AnimatePresence>
              {isEditing && (
                <motion.div
                  className="mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="glass-card rounded-2xl p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-medium text-[#1a1a1a] flex items-center gap-2">
                        <Edit3 className="w-4 h-4 text-[#6b7280]" />
                        编辑资料
                      </h3>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="p-1.5 text-[#9ca3af] hover:text-[#1a1a1a]"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs text-[#9ca3af] mb-1.5">身份标签</label>
                        <input
                          type="text"
                          value={editForm.tag}
                          onChange={(e) => setEditForm({ ...editForm, tag: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#fafafa] border border-transparent rounded-xl text-sm text-[#1a1a1a] focus:outline-none focus:bg-white focus:border-[rgba(0,0,0,0.08)] transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-[#9ca3af] mb-1.5">个人Slogan</label>
                        <textarea
                          rows={2}
                          value={editForm.slogan}
                          onChange={(e) => setEditForm({ ...editForm, slogan: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#fafafa] border border-transparent rounded-xl text-sm text-[#1a1a1a] focus:outline-none focus:bg-white focus:border-[rgba(0,0,0,0.08)] resize-none transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-[#9ca3af] mb-1.5">所在地</label>
                        <input
                          type="text"
                          value={editForm.location}
                          onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#fafafa] border border-transparent rounded-xl text-sm text-[#1a1a1a] focus:outline-none focus:bg-white focus:border-[rgba(0,0,0,0.08)] transition-all"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 mt-4">
                      <button
                        onClick={() => setIsEditing(false)}
                        className="flex-1 px-4 py-2.5 border border-[rgba(0,0,0,0.08)] rounded-xl text-[#6b7280] hover:bg-[#fafafa] text-sm transition-colors"
                      >
                        取消
                      </button>
                      <button
                        onClick={handleSave}
                        className="flex-1 px-4 py-2.5 bg-[#1a1a1a] text-white rounded-xl hover:bg-[#333] flex items-center justify-center gap-2 text-sm transition-colors"
                      >
                        <Save className="w-4 h-4" />
                        保存
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {showBgSettings && (
                <motion.div
                  className="mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="glass-card rounded-2xl p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-medium text-[#1a1a1a] flex items-center gap-2">
                        <Image className="w-4 h-4 text-[#6b7280]" />
                        背景图设置
                      </h3>
                      <button
                        onClick={() => setShowBgSettings(false)}
                        className="p-1.5 text-[#9ca3af] hover:text-[#1a1a1a]"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="mb-4">
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileSelect}
                        accept="image/*"
                        className="hidden"
                      />
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isUploading}
                        className="w-full px-4 py-3 border border-dashed border-[rgba(0,0,0,0.15)] rounded-xl text-[#6b7280] hover:border-[#1a1a1a] hover:text-[#1a1a1a] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {isUploading ? (
                          <>
                            <div className="w-4 h-4 border-2 border-gray-300 border-t-[#1a1a1a] rounded-full animate-spin" />
                            <span>上传中...</span>
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            <span>上传背景图</span>
                          </>
                        )}
                      </button>
                      {uploadError && (
                        <p className="mt-2 text-xs text-red-500">{uploadError}</p>
                      )}
                      <p className="mt-2 text-xs text-[#9ca3af]">支持 JPG、PNG 格式，最大 5MB</p>
                    </div>

                    {backgroundImages.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="text-xs text-[#9ca3af]">我的背景图</h4>
                        <div className="grid grid-cols-2 gap-3">
                          {backgroundImages.map((img) => (
                            <motion.div
                              key={img.id}
                              className={`relative aspect-video rounded-xl overflow-hidden border-2 transition-colors ${
                                img.isActive ? 'border-[#1a1a1a]' : 'border-transparent'
                              }`}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                            >
                              <img
                                src={img.url}
                                alt="背景图"
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                                <div className="flex items-center gap-1">
                                  {getStatusIcon(img.status)}
                                  <span className="text-xs text-white">{getStatusText(img.status)}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  {img.status === 'approved' && (
                                    <button
                                      onClick={() => handleSetActive(img.id)}
                                      className={`p-1.5 rounded-lg transition-colors ${
                                        img.isActive
                                          ? 'bg-[#1a1a1a] text-white'
                                          : 'bg-white/20 text-white hover:bg-white/30'
                                      }`}
                                    >
                                      <Check className="w-3 h-3" />
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleDelete(img.id)}
                                    className="p-1.5 bg-white/20 text-white hover:bg-red-500/80 rounded-lg transition-colors"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {!isEditing && !showBgSettings && (
              <motion.div
                className="glass-card rounded-2xl p-5 mb-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.35 }}
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-[#6b7280]">
                    <MapPin className="w-4 h-4 text-[#9ca3af]" />
                    <span>{profile.location}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-[#6b7280]">
                    <Calendar className="w-4 h-4 text-[#9ca3af]" />
                    <span>加入于 {profile.created_at?.split('T')[0]}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    {profile.is_public ? (
                      <>
                        <Eye className="w-4 h-4 text-green-500" />
                        <span className="text-green-600">公开收录</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-4 h-4 text-[#9ca3af]" />
                        <span className="text-[#6b7280]">私密状态</span>
                      </>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            <motion.div
              className="mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="flex items-center gap-2 mb-3 text-sm text-[#9ca3af]">
                <Send className="w-4 h-4" />
                <span>记录今日认知</span>
              </div>
              <div className="glass-card rounded-2xl p-4">
                <textarea
                  rows={3}
                  value={newLogContent}
                  onChange={(e) => setNewLogContent(e.target.value)}
                  className="w-full px-0 py-0 bg-transparent border-0 text-[0.9375rem] text-[#1a1a1a] placeholder:text-[#9ca3af] focus:outline-none resize-none"
                  placeholder="分享你的想法..."
                />
                <div className="flex justify-end mt-3">
                  <motion.button
                    onClick={handlePublishLog}
                    disabled={isPublishing || !newLogContent.trim()}
                    className="px-4 py-2 bg-[#1a1a1a] text-white text-sm font-medium rounded-lg hover:bg-[#333] transition-colors disabled:opacity-40"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isPublishing ? '发布中...' : '发布'}
                  </motion.button>
                </div>
              </div>
            </motion.div>

            {logs.length > 0 && (
              <motion.div
                className="space-y-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.45 }}
              >
                <div className="flex items-center gap-2 text-sm text-[#9ca3af] mb-4">
                  <Clock className="w-4 h-4" />
                  <span>认知日志</span>
                </div>
                <div className="space-y-3">
                  {logs.map((log: LogData, index: number) => (
                    <motion.article
                      key={log.id}
                      className="glass-card rounded-2xl p-5"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.5 + index * 0.05 }}
                    >
                      <div className="flex items-center gap-2 text-xs text-[#9ca3af] mb-2">
                        <time>{log.createdAt}</time>
                      </div>
                      <p className="text-[0.9375rem] text-[#1a1a1a] leading-relaxed whitespace-pre-wrap">
                        {log.content}
                      </p>
                    </motion.article>
                  ))}
                </div>
              </motion.div>
            )}

            <motion.div
              className="mt-12 text-center text-xs text-[#9ca3af]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              时空锚点 · 2026-04-26 · 北京市延庆区
            </motion.div>
          </div>
        </main>
      </div>
    </>
  );
}
