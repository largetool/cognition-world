import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Settings, Share2, MapPin, Calendar, Eye, EyeOff, Send } from 'lucide-react';
import { SEOHead } from '../components/SEOHead';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { GlassCard } from '../components/GlassCard';
import { LogItem } from '../components/LogItem';
import { BlockedPage } from '../components/BlockedPage';
import { useAuth } from '../hooks/useAuth';
import { useUser } from '../hooks/useUser';
import { useIPCheck } from '../hooks/useIPCheck';
import { createLog } from '../utils/storage';
import { getUserSEO, isAdminFromProfile, getInitials, APP_CONFIG, getDefaultSEO } from '../types';
import { generateProfilePageSchema, generatePersonSchema } from '../utils/seo';
import type { Profile } from '../types';

const galaxyBg = new URL('../../assets/C2283395-46CF-48E8-B1EC-3813518039AE_2.jpg', import.meta.url).href;

export default function UserPage() {
  const { userId } = useParams<{ userId: string }>();
  const { user: currentUser } = useAuth() as { user: Profile | null };
  const { profile, logs, activeBackground, isLoading, error, refreshLogs } = useUser(userId);
  const { isBlocked, isLoading: ipLoading } = useIPCheck();
  const [logContent, setLogContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isCurrentUser = currentUser?.user_id === profile?.user_id;
  const isAdminUser = isAdminFromProfile(currentUser);
  const canPostLog = isCurrentUser || isAdminUser;

  const handleSubmitLog = async () => {
    if (!logContent.trim() || !profile) return;

    setIsSubmitting(true);
    const result = await createLog(profile.user_id, logContent.trim());

    if (result.success) {
      setLogContent('');
      refreshLogs();
    }

    setIsSubmitting(false);
  };

  if (ipLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[var(--accent)]" />
      </div>
    );
  }

  if (isBlocked) {
    return <BlockedPage />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[var(--accent)]" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <h1 className="text-2xl font-semibold text-[var(--text-primary)] mb-2">
            页面不存在
          </h1>
          <p className="text-[var(--text-secondary)] mb-6">
            该用户不存在或已被隐藏
          </p>
          <Link
            to="/"
            className="inline-flex items-center px-6 py-3 rounded-lg bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            返回首页
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      <SEOHead
        data={profile ? getUserSEO(profile) : getDefaultSEO()}
        jsonLd={profile ? {
          '@context': 'https://schema.org',
          ...generateProfilePageSchema(profile),
        } : undefined}
      />

      <div className="relative">
        <div
          className="absolute top-0 left-0 right-0 h-[50vh] bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('${activeBackground?.url || galaxyBg}')`,
            backgroundPosition: 'center top',
          }}
        />
        <div className="absolute top-0 left-0 right-0 h-[50vh] bg-user-gradient" />

        <div className="relative z-10">
          <div className="glass border-b border-white/20">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center justify-between h-16">
                <Link
                  to="/"
                  className="flex items-center space-x-2 text-[var(--text-primary)] hover:text-[var(--text-secondary)] transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                  <span>返回首页</span>
                </Link>

                <div className="flex items-center space-x-2">
                  {isAdminUser && (
                    <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-sm font-medium">
                      GM
                    </span>
                  )}
                  <button
                    onClick={async () => {
                      const url = `${window.location.origin}/#/${profile.user_id}`;
                      if (navigator.share) {
                        await navigator.share({
                          title: `${profile.username} - 认知界`,
                          text: profile.slogan || profile.tag,
                          url,
                        });
                      } else {
                        await navigator.clipboard.writeText(url);
                        alert('链接已复制到剪贴板');
                      }
                    }}
                    className="p-2 rounded-lg hover:bg-white/20 transition-colors"
                  >
                    <Share2 className="w-5 h-5 text-[var(--text-primary)]" />
                  </button>
                  {(isCurrentUser || isAdminUser) && (
                    <Link
                      to="/me"
                      className="p-2 rounded-lg hover:bg-white/20 transition-colors"
                    >
                      <Settings className="w-5 h-5 text-[var(--text-primary)]" />
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-col items-center"
            >
              <div className="w-24 h-24 rounded-2xl bg-[var(--accent)] flex items-center justify-center text-white text-4xl font-bold mb-6">
                {getInitials(profile.username)}
              </div>

              <h1 className="text-3xl sm:text-4xl font-bold text-[var(--text-primary)] mb-2">
                {profile.username}
              </h1>

              <p className="text-[var(--text-secondary)] mb-4">
                {profile.tag}
              </p>

              {profile.slogan && (
                <p className="text-lg text-[var(--text-tertiary)] text-center max-w-xl mb-8">
                  {profile.slogan}
                </p>
              )}

              <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-[var(--text-secondary)]">
                <div className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span>{profile.location}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>加入于 {new Date(profile.created_at || '').getFullYear()}</span>
                </div>
                <div className="flex items-center space-x-1">
                  {profile.is_public ? (
                    <>
                      <Eye className="w-4 h-4" />
                      <span>公开</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-4 h-4" />
                      <span>私密</span>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {canPostLog && (
          <GlassCard className="mb-8">
            <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">
              发布认知日志
            </h3>
            <textarea
              value={logContent}
              onChange={(e) => setLogContent(e.target.value)}
              placeholder="记录你的想法..."
              className="input-field min-h-[100px] resize-none mb-4"
            />
            <div className="flex justify-end">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSubmitLog}
                disabled={!logContent.trim() || isSubmitting}
                className="flex items-center space-x-2 px-6 py-2 rounded-lg bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] transition-colors disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? '发布中...' : '发布'}</span>
              </motion.button>
            </div>
          </GlassCard>
        )}

        <div>
          <h2 className="text-xl font-semibold text-[var(--text-primary)] mb-6">
            认知日志
          </h2>

          {logs.length > 0 ? (
            <div>
              {logs.map((log, index) => (
                <LogItem key={log.id} log={log} index={index} />
              ))}
            </div>
          ) : (
            <GlassCard className="text-center py-12">
              <p className="text-[var(--text-tertiary)]">
                暂无认知日志
              </p>
            </GlassCard>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
