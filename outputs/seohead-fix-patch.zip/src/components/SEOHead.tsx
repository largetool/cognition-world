import { useEffect } from 'react';
import type { SEOData } from '../types';

interface SEOHeadProps {
  data?: SEOData;
  jsonLd?: object | object[];
}

const DEFAULT_TITLE = '认知界 - 让AI认识每一个具体的普通人';
const DEFAULT_DESCRIPTION = '面向全球化的个人黄页索引，让 AI 认识每一个具体的普通人';

/**
 * SEOHead 组件 - 安全降级版本
 * 修复：Cannot read properties of undefined (reading 'title')
 * 策略：data 为可选参数，所有字段使用安全访问和默认值
 */
export function SEOHead({ data, jsonLd }: SEOHeadProps) {
  useEffect(() => {
    try {
      // 安全降级：确保 data 存在且字段有效
      const safeTitle = data?.title || DEFAULT_TITLE;
      const safeDescription = data?.description || DEFAULT_DESCRIPTION;
      const safeKeywords = data?.keywords?.join(', ') || '';
      const safeOgType = data?.ogType || 'website';
      const safeOgImage = data?.ogImage || '';
      const safeCanonicalUrl = data?.canonicalUrl || '';

      // 记录 SEO 渲染事件（用于监控）
      if (process.env.NODE_ENV === 'development' || window.location.hostname.includes('staging')) {
        // eslint-disable-next-line no-console
        console.info('[SEOHead] Rendered:', { title: safeTitle, hasData: !!data });
      }

      // 设置页面标题
      document.title = safeTitle;

      // 定义 meta 标签
      const metaTags = [
        { name: 'description', content: safeDescription },
        { name: 'keywords', content: safeKeywords },
        { property: 'og:title', content: safeTitle },
        { property: 'og:description', content: safeDescription },
        { property: 'og:type', content: safeOgType },
        { property: 'og:image', content: safeOgImage },
        { property: 'og:url', content: safeCanonicalUrl },
        { name: 'twitter:card', content: 'summary_large_image' },
        { name: 'twitter:title', content: safeTitle },
        { name: 'twitter:description', content: safeDescription },
        { name: 'twitter:image', content: safeOgImage },
      ];

      // 更新或创建 meta 标签
      metaTags.forEach(tag => {
        if (!tag.content) return;

        let element: HTMLMetaElement | null = null;

        if (tag.name) {
          element = document.querySelector(`meta[name="${tag.name}"]`);
          if (!element) {
            element = document.createElement('meta');
            element.setAttribute('name', tag.name);
            document.head.appendChild(element);
          }
        } else if (tag.property) {
          element = document.querySelector(`meta[property="${tag.property}"]`);
          if (!element) {
            element = document.createElement('meta');
            element.setAttribute('property', tag.property);
            document.head.appendChild(element);
          }
        }

        if (element) {
          element.setAttribute('content', tag.content);
        }
      });

      // 更新 canonical URL
      if (safeCanonicalUrl) {
        let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
        if (!canonical) {
          canonical = document.createElement('link');
          canonical.setAttribute('rel', 'canonical');
          document.head.appendChild(canonical);
        }
        canonical.setAttribute('href', safeCanonicalUrl);
      }

      // 更新 JSON-LD 结构化数据
      if (jsonLd) {
        const existingScript = document.querySelector('script[type="application/ld+json"]');
        if (existingScript) {
          existingScript.remove();
        }
        const script = document.createElement('script');
        script.setAttribute('type', 'application/ld+json');
        script.textContent = JSON.stringify(jsonLd);
        document.head.appendChild(script);
      }
    } catch (error) {
      // 捕获异常，避免页面崩溃
      // eslint-disable-next-line no-console
      console.error('[SEOHead] Error:', error);
    }
  }, [data, jsonLd]);

  return null;
}
