import { render } from '@testing-library/react';
import { SEOHead } from '../SEOHead';
import type { SEOData } from '../../types';

describe('SEOHead 安全降级测试', () => {
  const originalTitle = document.title;

  beforeEach(() => {
    document.title = originalTitle;
    // 清理已存在的 meta 标签
    document.querySelectorAll('meta[name="description"], meta[property^="og:"], meta[name^="twitter:"]').forEach(el => el.remove());
  });

  // 场景 1：完整数据
  it('应正确渲染完整 SEO 数据', () => {
    const fullData: SEOData = {
      title: '测试标题 - 认知界',
      description: '测试描述',
      keywords: ['测试', '关键词'],
      ogType: 'profile',
      ogImage: 'https://example.com/image.jpg',
      canonicalUrl: 'https://example.com/test',
    };

    render(<SEOHead data={fullData} />);

    expect(document.title).toBe('测试标题 - 认知界');
  });

  // 场景 2：部分字段缺失
  it('应在部分字段缺失时使用默认值', () => {
    const partialData: SEOData = {
      title: '部分数据标题',
      description: '',
    };

    render(<SEOHead data={partialData} />);

    expect(document.title).toBe('部分数据标题');
  });

  // 场景 3：无数据（undefined）
  it('应在 data 为 undefined 时使用安全降级', () => {
    render(<SEOHead data={undefined} />);

    expect(document.title).toBe('认知界 - 让AI认识每一个具体的普通人');
  });

  // 场景 4：data 为 null
  it('应在 data 为 null 时使用安全降级', () => {
    render(<SEOHead data={null as any} />);

    expect(document.title).toBe('认知界 - 让AI认识每一个具体的普通人');
  });

  // 场景 5：title 字段缺失
  it('应在 title 缺失时使用默认标题', () => {
    const noTitleData: SEOData = {
      title: undefined as any,
      description: '有描述但没有标题',
    };

    render(<SEOHead data={noTitleData} />);

    expect(document.title).toBe('认知界 - 让AI认识每一个具体的普通人');
  });
});
